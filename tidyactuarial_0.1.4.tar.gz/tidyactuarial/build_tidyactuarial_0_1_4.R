# build_tidyactuarial_0_1_4.R
# -------------------------------------------------------------------------
# Build source package tidyactuarial 0.1.4 for CRAN submission.
#
# Run this file from the package root, i.e. the folder containing DESCRIPTION.
#
#   source("build_tidyactuarial_0_1_4.R")
#
# The resulting .tar.gz file will be created in the parent directory of the
# package project, unless devtools chooses another build path.
# -------------------------------------------------------------------------

stop_if_not_package_root <- function() {
  required <- c("DESCRIPTION", "R", "NAMESPACE")
  missing <- required[!file.exists(required)]

  if (length(missing) > 0L) {
    stop(
      "Run this script from the package root. Missing: ",
      paste(missing, collapse = ", "),
      ".",
      call. = FALSE
    )
  }

  invisible(TRUE)
}

require_namespace <- function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    stop(
      "Package `", pkg, "` is required. Install it with install.packages('",
      pkg, "').",
      call. = FALSE
    )
  }

  invisible(TRUE)
}

clean_local_artifacts <- function() {
  unlink("check", recursive = TRUE, force = TRUE)
  unlink("data/_backup_pre_param_migration_0_1_4", recursive = TRUE, force = TRUE)

  extra_root_files <- c(
    "strict_check_tidyactuarial_0_1_4.R",
    "api_registry_0_1_4.csv",
    "api_registry_0_1_4_classified.csv",
    "api_registry_0_1_4_targets.csv"
  )

  existing <- extra_root_files[file.exists(extra_root_files)]

  if (length(existing) > 0L) {
    message(
      "Local helper files found at package root. They should be removed or ",
      "listed in .Rbuildignore before CRAN build:\n  ",
      paste(existing, collapse = "\n  ")
    )
  }

  invisible(TRUE)
}

ensure_build_ignore <- function() {
  require_namespace("usethis")

  usethis::use_build_ignore(c(
    "^check$",
    "^strict_check_tidyactuarial_0_1_4[.]R$",
    "^api_registry_0_1_4[.]csv$",
    "^api_registry_0_1_4_classified[.]csv$",
    "^api_registry_0_1_4_targets[.]csv$",
    "^data/_backup_pre_param_migration_0_1_4$"
  ))

  invisible(TRUE)
}

set_package_version <- function(version = "0.1.4") {
  require_namespace("desc")

  desc::desc_set_version(version)
  message("DESCRIPTION version set to ", version)

  invisible(TRUE)
}

run_prebuild_checks <- function() {
  require_namespace("devtools")

  message("\nStep 1: document()")
  devtools::document()

  message("\nStep 2: test()")
  devtools::test()

  message("\nStep 3: check()")
  devtools::check(
    document = FALSE,
    manual = TRUE,
    vignettes = TRUE,
    cran = TRUE
  )

  invisible(TRUE)
}

build_source_package <- function() {
  require_namespace("devtools")

  message("\nStep 4: build source package")
  tarball <- devtools::build(
    path = ".",
    binary = FALSE,
    vignettes = TRUE,
    manual = TRUE,
    args = c("--compact-vignettes=gs+qpdf")
  )

  message("\nBuild complete.")
  message("Source package:")
  message("  ", normalizePath(tarball, winslash = "/", mustWork = FALSE))

  invisible(tarball)
}

build_tidyactuarial_0_1_4 <- function() {
  stop_if_not_package_root()

  require_namespace("desc")
  require_namespace("devtools")
  require_namespace("usethis")

  clean_local_artifacts()
  ensure_build_ignore()
  set_package_version("0.1.4")

  run_prebuild_checks()
  tarball <- build_source_package()

  message("\nReady for CRAN upload if check ended with 0 errors and 0 warnings.")
  message("Upload the .tar.gz source package generated above.")

  invisible(tarball)
}

build_tidyactuarial_0_1_4()
