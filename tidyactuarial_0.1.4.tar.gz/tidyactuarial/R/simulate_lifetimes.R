#' Simulate multiple independent future lifetimes
#'
#' Simulates curtate and complete future lifetimes for several independent
#' lives from one or more life tables, using compact actuarial notation.
#'
#' This function is the multiple-life analogue of \code{\link{simulate_lifetime}}.
#' It returns a tidy long table with one row per simulation and per life. The
#' output is designed to feed naturally into \code{\link{mc_multilife_status}},
#' \code{\link{mc_insurance}}, \code{\link{mc_annuity}},
#' \code{\link{mc_premium}}, \code{\link{mc_loss}}, and
#' \code{\link{mc_reserve}}.
#'
#' @param lt A life table data frame or a list of life table data frames. If a
#'   single data frame is supplied, the same table is used for all lives. If a
#'   list is supplied, it must have length 1 or length equal to \code{length(x)}.
#' @param x Numeric vector. Initial actuarial ages of the lives to simulate.
#' @param n_sim Positive integer. Number of Monte Carlo simulations per life.
#' @param life_id Optional character vector identifying each life. If
#'   \code{NULL}, identifiers are created automatically as \code{"life_1"},
#'   \code{"life_2"}, and so on. If \code{lt} is a named list and
#'   \code{life_id = NULL}, the list names are used when possible.
#' @param col_x Character string. Name of the age column in the life table or
#'   life tables. Default is \code{"x"}. If \code{col_x = "x"} is not found but
#'   a legacy \code{"age"} column exists, it is used automatically.
#' @param col_qx Character string. Name of the one-year death probability
#'   column. Default is \code{"qx"}.
#' @param method Character string specifying the simulation method for each
#'   curtate future lifetime. One of \code{"inverse"}, \code{"multinomial"},
#'   or \code{"antithetic"}.
#' @param frac Character string specifying how the fractional part of the
#'   complete future lifetime is generated within the year of death. Canonical
#'   values are \code{"UDD"}, \code{"CF"}, and \code{"none"}. Transitional
#'   aliases \code{"udd"}, \code{"constant_force"}, and \code{"cf"} are also
#'   accepted.
#' @param seed Optional integer seed for reproducibility.
#' @param ... Transitional compatibility for older calls using \code{data},
#'   \code{ages}, \code{age_col}, \code{qx_col}, and \code{fractional}.
#'
#' @details
#' For lives aged \eqn{x_1, x_2, \ldots, x_r}, the function simulates
#' independent curtate future lifetimes
#' \deqn{
#' K_{x_1}, K_{x_2}, \ldots, K_{x_r}.
#' }
#'
#' When \code{frac != "none"}, the function also simulates complete future
#' lifetimes
#' \deqn{
#' T_{x_1}, T_{x_2}, \ldots, T_{x_r}.
#' }
#'
#' The independence assumption means that no common shock, frailty, copula, or
#' other dependence structure is imposed. Joint-life, last-survivor, k-th death,
#' and at-least-k-alive statuses can then be constructed with
#' \code{\link{mc_multilife_status}}.
#'
#' This function uses the compact actuarial notation adopted in
#' \code{tidyactuarial}: \code{lt} denotes the life table input, \code{x}
#' denotes ages, \code{Kx} denotes curtate future lifetime, and \code{Tx}
#' denotes complete future lifetime.
#'
#' For transition, the output also includes legacy columns \code{age} and
#' \code{fractional}, alongside the canonical columns \code{x} and \code{frac}.
#'
#' @return A tibble with one row per simulation and per life. It contains:
#' \describe{
#'   \item{sim_id}{Simulation identifier.}
#'   \item{life_id}{Life identifier.}
#'   \item{life_index}{Position of the life in \code{x}.}
#'   \item{x}{Initial actuarial age.}
#'   \item{age}{Legacy alias of \code{x}.}
#'   \item{method}{Simulation method.}
#'   \item{frac}{Canonical fractional-age assumption.}
#'   \item{fractional}{Legacy fractional-age label.}
#'   \item{Kx}{Simulated curtate future lifetime.}
#'   \item{Tx}{Simulated complete future lifetime. If \code{frac = "none"},
#'   this column contains \code{NA}.}
#' }
#'
#' @seealso \code{\link{simulate_lifetime}},
#'   \code{\link{mc_multilife_status}}, \code{\link{summary_mc}}
#'
#' @references
#' Bowers, N. L., Gerber, H. U., Hickman, J. C., Jones, D. A.,
#' and Nesbitt, C. J. (1997). \emph{Actuarial Mathematics}. Second Edition.
#' Society of Actuaries.
#'
#' @family monte-carlo
#'
#' @examples
#' lt <- tibble::tibble(
#'   x = 40:110,
#'   qx = seq(0.002, 1, length.out = 71)
#' )
#'
#' # Two independent lives using the same life table
#' lt |>
#'   simulate_lifetimes(
#'     x = c(60, 58),
#'     n_sim = 25,
#'     seed = 123
#'   )
#'
#' # Three independent lives
#' lt |>
#'   simulate_lifetimes(
#'     x = c(60, 58, 55),
#'     life_id = c("x", "y", "z"),
#'     n_sim = 25,
#'     seed = 123
#'   )
#'
#' # Different life tables for different lives
#' male_table <- tibble::tibble(
#'   x = 40:110,
#'   qx = seq(0.003, 1, length.out = 71)
#' )
#'
#' female_table <- tibble::tibble(
#'   x = 40:110,
#'   qx = seq(0.002, 1, length.out = 71)
#' )
#'
#' list(male = male_table, female = female_table) |>
#'   simulate_lifetimes(
#'     x = c(60, 58),
#'     n_sim = 25,
#'     seed = 123
#'   )
#'
#' # Transitional compatibility with old names
#' lt |>
#'   simulate_lifetimes(
#'     ages = c(60, 58),
#'     n_sim = 25,
#'     fractional = "udd",
#'     seed = 123
#'   )
#'
#' @export
simulate_lifetimes <- function(
    lt,
    x = NULL,
    n_sim = 10000L,
    life_id = NULL,
    col_x = "x",
    col_qx = "qx",
    method = c("inverse", "multinomial", "antithetic"),
    frac = c("UDD", "CF", "none", "udd", "constant_force", "cf"),
    seed = NULL,
    ...
) {
  dots <- list(...)

  # -------------------------------------------------------------------------
  # Transitional compatibility with the previous public API
  # -------------------------------------------------------------------------

  allowed_old <- c(
    "data",
    "ages",
    "age_col",
    "qx_col",
    "fractional"
  )

  bad_dots <- setdiff(names(dots), allowed_old)

  if (length(bad_dots) > 0L) {
    stop(
      "Unused argument(s): ",
      paste(sprintf("`%s`", bad_dots), collapse = ", "),
      ".",
      call. = FALSE
    )
  }

  if (!is.null(dots$data)) {
    if (!missing(lt)) {
      stop("Provide only one of `lt` or deprecated `data`.", call. = FALSE)
    }

    lt <- dots$data
  }

  if (!is.null(dots$ages)) {
    if (!is.null(x)) {
      stop("Provide only one of `x` or deprecated `ages`.", call. = FALSE)
    }

    x <- dots$ages
  }

  if (!is.null(dots$age_col)) {
    if (!identical(col_x, "x")) {
      stop("Provide only one of `col_x` or deprecated `age_col`.",
           call. = FALSE)
    }

    col_x <- dots$age_col
  }

  if (!is.null(dots$qx_col)) {
    if (!identical(col_qx, "qx")) {
      stop("Provide only one of `col_qx` or deprecated `qx_col`.",
           call. = FALSE)
    }

    col_qx <- dots$qx_col
  }

  if (!is.null(dots$fractional)) {
    if (!missing(frac)) {
      stop("Provide only one of `frac` or deprecated `fractional`.",
           call. = FALSE)
    }

    frac <- dots$fractional
  }

  method <- match.arg(method)
  frac <- match.arg(frac)

  if (frac == "udd") {
    frac <- "UDD"
  }

  if (frac %in% c("constant_force", "cf")) {
    frac <- "CF"
  }

  fractional_legacy <- switch(
    frac,
    UDD = "udd",
    CF = "constant_force",
    none = "none"
  )

  # -------------------------------------------------------------------------
  # Validation
  # -------------------------------------------------------------------------

  if (missing(lt)) {
    stop("`lt` must be provided.", call. = FALSE)
  }

  if (is.null(x)) {
    stop("`x` must be provided.", call. = FALSE)
  }

  if (!is.numeric(x) ||
      length(x) == 0L ||
      anyNA(x) ||
      any(!is.finite(x))) {
    stop("`x` must be a numeric vector without missing values.", call. = FALSE)
  }

  if (any(x < 0)) {
    stop("All values in `x` must be non-negative.", call. = FALSE)
  }

  .mc_assert_positive_integer(n_sim, "n_sim")
  .mc_assert_character_scalar(col_x, "col_x")
  .mc_assert_character_scalar(col_qx, "col_qx")

  n_lives <- length(x)

  if (is.data.frame(lt)) {
    life_tables <- rep(list(lt), n_lives)
  } else if (is.list(lt)) {
    if (!length(lt) %in% c(1L, n_lives)) {
      stop(
        "`lt` must be a data frame or a list of length 1 or length equal ",
        "to `length(x)`.",
        call. = FALSE
      )
    }

    if (!all(vapply(lt, is.data.frame, logical(1L)))) {
      stop("Every element of `lt` must be a data frame or tibble.",
           call. = FALSE)
    }

    life_tables <- if (length(lt) == 1L) {
      rep(lt, n_lives)
    } else {
      lt
    }
  } else {
    stop(
      "`lt` must be a life table data frame or a list of life table data frames.",
      call. = FALSE
    )
  }

  if (is.null(life_id)) {
    lt_names <- names(lt)

    if (is.list(lt) &&
        length(lt) == n_lives &&
        !is.null(lt_names) &&
        all(nzchar(lt_names))) {
      life_id <- lt_names
    } else {
      life_id <- paste0("life_", seq_len(n_lives))
    }
  }

  if (!is.character(life_id) ||
      length(life_id) != n_lives ||
      anyNA(life_id) ||
      any(!nzchar(life_id))) {
    stop(
      "`life_id` must be NULL or a non-missing character vector with length ",
      "equal to `length(x)`.",
      call. = FALSE
    )
  }

  if (anyDuplicated(life_id)) {
    stop("`life_id` values must be unique.", call. = FALSE)
  }

  if (!is.null(seed)) {
    .mc_assert_positive_integer(seed, "seed")
    set.seed(seed)
  }

  # -------------------------------------------------------------------------
  # Internal simulator
  # -------------------------------------------------------------------------

  simulate_one_life <- function(tab, x0) {
    tab <- tibble::as_tibble(tab)

    effective_col_x <- col_x

    if (!effective_col_x %in% names(tab) &&
        identical(effective_col_x, "x") &&
        "age" %in% names(tab)) {
      effective_col_x <- "age"
    }

    if (!effective_col_x %in% names(tab)) {
      stop(
        "`col_x` was not found in one life table. Expected column `",
        col_x, "`.",
        call. = FALSE
      )
    }

    if (!col_qx %in% names(tab)) {
      stop(
        "`col_qx` was not found in one life table. Expected column `",
        col_qx, "`.",
        call. = FALSE
      )
    }

    age_vec <- tab[[effective_col_x]]
    qx_vec <- tab[[col_qx]]

    if (!is.numeric(age_vec)) {
      stop("The selected age column must be numeric.", call. = FALSE)
    }

    if (!is.numeric(qx_vec)) {
      stop("The selected qx column must be numeric.", call. = FALSE)
    }

    if (anyNA(age_vec) || any(!is.finite(age_vec))) {
      stop("The selected age column must contain finite values.", call. = FALSE)
    }

    if (anyNA(qx_vec) || any(!is.finite(qx_vec))) {
      stop("The selected qx column must contain finite values.", call. = FALSE)
    }

    if (any(qx_vec < 0 | qx_vec > 1)) {
      stop("All death probabilities in `col_qx` must be between 0 and 1.",
           call. = FALSE)
    }

    keep <- age_vec >= x0

    if (!any(keep)) {
      stop(
        "No ages greater than or equal to the selected issue age were found ",
        "in one life table.",
        call. = FALSE
      )
    }

    dist <- data.frame(
      attained_age = age_vec[keep],
      qx = qx_vec[keep]
    )

    dist <- dist[order(dist$attained_age), , drop = FALSE]

    dist$Kx <- dist$attained_age - x0

    if (any(dist$Kx < 0) || any(diff(dist$Kx) < 0)) {
      stop("The selected age column must be ordered or orderable by age.",
           call. = FALSE)
    }

    dist$px <- 1 - dist$qx

    if (nrow(dist) == 1L) {
      survival_to_k <- 1
    } else {
      survival_to_k <- c(1, cumprod(dist$px[-nrow(dist)]))
    }

    dist$survival_to_k <- survival_to_k
    dist$prob <- dist$survival_to_k * dist$qx

    total_prob <- sum(dist$prob)

    if (total_prob <= 0 || is.na(total_prob)) {
      stop(
        "The simulated lifetime distribution has zero total probability.",
        call. = FALSE
      )
    }

    dist$prob <- dist$prob / total_prob
    dist$cdf <- cumsum(dist$prob)
    dist$cdf[nrow(dist)] <- 1

    if (method == "multinomial") {
      Kx <- sample(
        x = dist$Kx,
        size = n_sim,
        replace = TRUE,
        prob = dist$prob
      )
    } else {
      n_u <- if (method == "antithetic") ceiling(n_sim / 2) else n_sim
      u <- stats::runif(n_u)

      if (method == "antithetic") {
        u <- c(u, 1 - u)[seq_len(n_sim)]
      }

      index <- findInterval(
        x = u,
        vec = c(0, dist$cdf),
        rightmost.closed = TRUE
      )

      index[index < 1L] <- 1L
      index[index > nrow(dist)] <- nrow(dist)

      Kx <- dist$Kx[index]
    }

    Tx <- rep(NA_real_, n_sim)

    if (frac == "UDD") {
      Tx <- Kx + stats::runif(n_sim)
    }

    if (frac == "CF") {
      qx_by_K <- stats::setNames(dist$qx, dist$Kx)
      q_death <- unname(qx_by_K[as.character(Kx)])

      u_frac <- stats::runif(n_sim)

      Tx <- Kx + ifelse(
        q_death <= 0,
        0,
        log(1 - u_frac * q_death) / log(1 - q_death)
      )
    }

    tibble::tibble(
      sim_id = seq_len(n_sim),
      x = x0,
      age = x0,
      method = method,
      frac = frac,
      fractional = fractional_legacy,
      Kx = Kx,
      Tx = Tx
    )
  }

  # -------------------------------------------------------------------------
  # Simulation for all lives
  # -------------------------------------------------------------------------

  simulated_list <- lapply(
    seq_len(n_lives),
    function(j) {
      simulate_one_life(
        tab = life_tables[[j]],
        x0 = x[[j]]
      ) |>
        dplyr::mutate(
          life_id = life_id[[j]],
          life_index = j,
          .before = "x"
        ) |>
        dplyr::select(
          .data$sim_id,
          .data$life_id,
          .data$life_index,
          .data$x,
          .data$age,
          dplyr::everything()
        )
    }
  )

  dplyr::bind_rows(simulated_list)
}
