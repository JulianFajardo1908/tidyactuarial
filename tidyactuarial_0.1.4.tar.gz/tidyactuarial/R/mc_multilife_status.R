#' Construct multiple-life status lifetimes from simulated lives
#'
#' Constructs simulated multiple-life status lifetimes from simulated individual
#' lifetimes in long format, using compact actuarial notation.
#'
#' This function is designed to be used after \code{\link{simulate_lifetimes}}.
#' It takes one row per simulation and per life, and returns one row per
#' simulation with simulated curtate and complete lifetimes for the selected
#' multiple-life status.
#'
#' The key output columns are \code{K_status} and \code{T_status}. They are
#' intentionally named so they can be used directly in downstream Monte Carlo
#' functions such as \code{\link{mc_insurance}} and \code{\link{mc_annuity}}
#' through their lifetime-column arguments.
#'
#' @param .data A data frame or tibble containing simulated multiple-life
#'   lifetimes, typically returned by \code{\link{simulate_lifetimes}}.
#' @param status Character string specifying the multiple-life status. New
#'   canonical options are \code{"joint"}, \code{"last"}, \code{"kth_death"},
#'   and \code{"at_least_k_alive"}. Transitional aliases
#'   \code{"joint_life"}, \code{"first_death"}, \code{"last_survivor"}, and
#'   \code{"last_death"} are also accepted.
#' @param k Optional positive integer. Required when
#'   \code{status = "kth_death"} or \code{status = "at_least_k_alive"}.
#' @param col_sim Character string. Name of the simulation identifier column.
#'   Default is \code{"sim_id"}.
#' @param col_life Character string. Name of the life identifier column.
#'   Default is \code{"life_id"}.
#' @param col_K Character string. Name of the column containing simulated
#'   curtate future lifetimes. Default is \code{"Kx"}.
#' @param col_T Character string. Name of the column containing simulated
#'   complete future lifetimes. Default is \code{"Tx"}.
#' @param col_K_status Character string. Name of the output column containing
#'   the curtate lifetime of the multiple-life status. Default is
#'   \code{"K_status"}.
#' @param col_T_status Character string. Name of the output column containing
#'   the complete lifetime of the multiple-life status. Default is
#'   \code{"T_status"}.
#' @param keep_lifetimes Logical scalar. If \code{TRUE}, the output includes a
#'   list-column named \code{lifetimes} containing the simulated individual
#'   lifetimes used in each simulation. Default is \code{FALSE}.
#' @param ... Transitional compatibility for older calls using \code{data},
#'   \code{sim_col}, \code{life_col}, \code{k_col}, \code{tx_col},
#'   \code{k_status_col}, and \code{t_status_col}.
#'
#' @details
#' This function follows the compact actuarial notation used throughout
#' \code{tidyactuarial}: \code{K} denotes curtate future lifetime and
#' \code{T} denotes complete future lifetime.
#'
#' Suppose that, for a given simulation, the complete future lifetimes of
#' \eqn{r} lives are
#' \deqn{T_1, T_2, \ldots, T_r.}
#'
#' Let
#' \deqn{T_{(1)} \le T_{(2)} \le \cdots \le T_{(r)}}
#' denote the ordered lifetimes. The selected multiple-life status is converted
#' into an order statistic:
#'
#' \itemize{
#'   \item \code{"joint"}: joint-life status, fails at the first death,
#'   \eqn{T_{(1)}}.
#'   \item \code{"last"}: last-survivor status, fails at the last death,
#'   \eqn{T_{(r)}}.
#'   \item \code{"kth_death"}: time until the \eqn{k}-th death,
#'   \eqn{T_{(k)}}.
#'   \item \code{"at_least_k_alive"}: status remains active while at least
#'   \eqn{k} lives are alive, and fails at the \eqn{(r-k+1)}-th death.
#' }
#'
#' The same order-statistic logic is applied to curtate future lifetimes
#' \eqn{K_1, K_2, \ldots, K_r}, producing \code{K_status}.
#'
#' The aliases \code{"joint_life"} and \code{"first_death"} are mapped to
#' \code{"joint"}. The aliases \code{"last_survivor"} and \code{"last_death"}
#' are mapped to \code{"last"}.
#'
#' @return A tibble with one row per simulation and the following columns:
#' \describe{
#'   \item{sim_id}{Simulation identifier, or the column named by
#'   \code{col_sim}.}
#'   \item{status}{Canonical multiple-life status.}
#'   \item{n_lives}{Number of lives in the simulation.}
#'   \item{k}{Value of \code{k}, when applicable.}
#'   \item{status_rank}{Order statistic rank used to define the status.}
#'   \item{K_status}{Simulated curtate lifetime of the status, or another name
#'   supplied through \code{col_K_status}.}
#'   \item{T_status}{Simulated complete lifetime of the status, or another name
#'   supplied through \code{col_T_status}. If complete lifetimes are unavailable,
#'   this column contains \code{NA}.}
#'   \item{event_life_id}{Identifier of the life or lives associated with the
#'   status event time.}
#'   \item{n_event_lives}{Number of lives tied at the status event time.}
#' }
#'
#' If \code{keep_lifetimes = TRUE}, a list-column named \code{lifetimes} is
#' also returned.
#'
#' @seealso \code{\link{simulate_lifetimes}}, \code{\link{simulate_lifetime}},
#'   \code{\link{mc_insurance}}, \code{\link{mc_annuity}},
#'   \code{\link{summary_mc}}
#'
#' @references
#' Bowers, N. L., Gerber, H. U., Hickman, J. C., Jones, D. A.,
#' and Nesbitt, C. J. (1997). \emph{Actuarial Mathematics}. Second Edition.
#' Society of Actuaries.
#'
#' @family monte-carlo
#'
#' @examples
#' lt <- tibble::tibble(
#'   x = 60:90,
#'   qx = seq(0.01, 1, length.out = 31)
#' )
#'
#' # Simulated lifetimes for two independent lives
#' sim_two <- lt |>
#'   simulate_lifetimes(
#'     x = c(60, 58),
#'     n_sim = 25,
#'     seed = 123
#'   )
#'
#' # Joint-life status: time until the first death
#' mc_multilife_status(
#'   sim_two,
#'   status = "joint"
#' )
#'
#' # Last-survivor status: time until the last death
#' mc_multilife_status(
#'   sim_two,
#'   status = "last"
#' )
#'
#' # Simulated lifetimes for three independent lives
#' sim_three <- lt |>
#'   simulate_lifetimes(
#'     x = c(60, 58, 55),
#'     life_id = c("x", "y", "z"),
#'     n_sim = 25,
#'     seed = 123
#'   )
#'
#' # Time until the second death among three lives
#' mc_multilife_status(
#'   sim_three,
#'   status = "kth_death",
#'   k = 2
#' )
#'
#' # Status active while at least two lives are alive
#' mc_multilife_status(
#'   sim_three,
#'   status = "at_least_k_alive",
#'   k = 2
#' )
#'
#' # Transitional compatibility with older status labels
#' mc_multilife_status(
#'   sim_two,
#'   status = "joint_life"
#' )
#'
#' @export
mc_multilife_status <- function(
    .data = NULL,
    status = c(
      "joint",
      "last",
      "kth_death",
      "at_least_k_alive",
      "joint_life",
      "first_death",
      "last_survivor",
      "last_death"
    ),
    k = NULL,
    col_sim = "sim_id",
    col_life = "life_id",
    col_K = "Kx",
    col_T = "Tx",
    col_K_status = "K_status",
    col_T_status = "T_status",
    keep_lifetimes = FALSE,
    ...
) {
  dots <- list(...)

  # -------------------------------------------------------------------------
  # Transitional compatibility with the previous public API
  # -------------------------------------------------------------------------

  allowed_old <- c(
    "data",
    "sim_col",
    "life_col",
    "k_col",
    "tx_col",
    "k_status_col",
    "t_status_col"
  )

  bad_dots <- setdiff(names(dots), allowed_old)

  if (length(bad_dots) > 0L) {
    stop(
      "Unused argument(s): ",
      paste(sprintf("`%s`", bad_dots), collapse = ", "),
      ".",
      call. = FALSE
    )
  }

  if (!is.null(dots$data)) {
    if (!is.null(.data)) {
      stop("Provide only one of `.data` or deprecated `data`.", call. = FALSE)
    }

    .data <- dots$data
  }

  if (!is.null(dots$sim_col)) {
    if (!identical(col_sim, "sim_id")) {
      stop("Provide only one of `col_sim` or deprecated `sim_col`.", call. = FALSE)
    }

    col_sim <- dots$sim_col
  }

  if (!is.null(dots$life_col)) {
    if (!identical(col_life, "life_id")) {
      stop("Provide only one of `col_life` or deprecated `life_col`.", call. = FALSE)
    }

    col_life <- dots$life_col
  }

  if (!is.null(dots$k_col)) {
    if (!identical(col_K, "Kx")) {
      stop("Provide only one of `col_K` or deprecated `k_col`.", call. = FALSE)
    }

    col_K <- dots$k_col
  }

  if (!is.null(dots$tx_col)) {
    if (!identical(col_T, "Tx")) {
      stop("Provide only one of `col_T` or deprecated `tx_col`.", call. = FALSE)
    }

    col_T <- dots$tx_col
  }

  if (!is.null(dots$k_status_col)) {
    if (!identical(col_K_status, "K_status")) {
      stop(
        "Provide only one of `col_K_status` or deprecated `k_status_col`.",
        call. = FALSE
      )
    }

    col_K_status <- dots$k_status_col
  }

  if (!is.null(dots$t_status_col)) {
    if (!identical(col_T_status, "T_status")) {
      stop(
        "Provide only one of `col_T_status` or deprecated `t_status_col`.",
        call. = FALSE
      )
    }

    col_T_status <- dots$t_status_col
  }

  status <- match.arg(status)

  canonical_status <- .mc_multilife_normalize_status(status)

  if (!is.data.frame(.data)) {
    stop("`.data` must be a data frame or tibble.", call. = FALSE)
  }

  .mc_assert_column(.data, col_sim, "col_sim")
  .mc_assert_column(.data, col_life, "col_life")
  .mc_assert_numeric_column(.data, col_K, "col_K")
  .mc_assert_character_scalar(col_T, "col_T")
  .mc_assert_character_scalar(col_K_status, "col_K_status")
  .mc_assert_character_scalar(col_T_status, "col_T_status")

  if (col_K_status == col_T_status) {
    stop("`col_K_status` and `col_T_status` must have different names.", call. = FALSE)
  }

  has_T <- col_T %in% names(.data)

  if (has_T && !is.numeric(.data[[col_T]])) {
    stop("`col_T` must identify a numeric column when it exists in `.data`.",
         call. = FALSE)
  }

  has_T <- has_T && !all(is.na(.data[[col_T]]))

  if (!is.logical(keep_lifetimes) ||
      length(keep_lifetimes) != 1L ||
      is.na(keep_lifetimes)) {
    stop("`keep_lifetimes` must be a logical scalar.", call. = FALSE)
  }

  if (canonical_status %in% c("kth_death", "at_least_k_alive")) {
    .mc_assert_positive_integer(k, "k")
  }

  summarise_status_one <- function(df) {
    K_values <- df[[col_K]]
    life_ids <- as.character(df[[col_life]])

    if (anyNA(K_values)) {
      stop(
        "The selected curtate lifetime column contains missing values within a simulation.",
        call. = FALSE
      )
    }

    n_lives <- length(K_values)

    if (n_lives == 0L) {
      stop("Each simulation must contain at least one life.", call. = FALSE)
    }

    status_rank <- .mc_multilife_status_rank(
      status = canonical_status,
      k = k,
      n_lives = n_lives
    )

    k_used <- if (canonical_status %in% c("kth_death", "at_least_k_alive")) {
      as.integer(k)
    } else {
      NA_integer_
    }

    K_status <- sort(K_values)[[status_rank]]

    if (has_T) {
      T_values <- df[[col_T]]

      if (anyNA(T_values)) {
        stop(
          "The selected complete lifetime column contains missing values within a simulation.",
          call. = FALSE
        )
      }

      T_status <- sort(T_values)[[status_rank]]
      tied <- abs(T_values - T_status) <= sqrt(.Machine$double.eps)
    } else {
      T_status <- NA_real_
      tied <- abs(K_values - K_status) <= sqrt(.Machine$double.eps)
    }

    event_life_id <- paste(life_ids[tied], collapse = ",")
    n_event_lives <- sum(tied)

    out <- tibble::tibble(
      status = canonical_status,
      n_lives = n_lives,
      k = k_used,
      status_rank = status_rank,
      "{col_K_status}" := K_status,
      "{col_T_status}" := T_status,
      event_life_id = event_life_id,
      n_event_lives = n_event_lives
    )

    if (keep_lifetimes) {
      lifetimes_tbl <- tibble::tibble(
        life_id = life_ids,
        Kx = K_values,
        Tx = if (has_T) df[[col_T]] else NA_real_
      )

      out <- dplyr::mutate(
        out,
        lifetimes = list(lifetimes_tbl)
      )
    }

    out
  }

  .data |>
    dplyr::ungroup() |>
    dplyr::group_by(dplyr::across(dplyr::all_of(col_sim))) |>
    dplyr::group_modify(~ summarise_status_one(.x)) |>
    dplyr::ungroup()
}


#' Internal helper: normalize multiple-life Monte Carlo status names
#'
#' @param status Character string.
#'
#' @return Canonical status name.
#'
#' @keywords internal
.mc_multilife_normalize_status <- function(status) {
  if (status %in% c("joint", "joint_life", "first_death")) {
    return("joint")
  }

  if (status %in% c("last", "last_survivor", "last_death")) {
    return("last")
  }

  if (status %in% c("kth_death", "at_least_k_alive")) {
    return(status)
  }

  stop("Unknown multiple-life status.", call. = FALSE)
}


#' Internal helper: determine order statistic rank for a multiple-life status
#'
#' @param status Character string with the canonical multiple-life status.
#' @param k Optional positive integer.
#' @param n_lives Positive integer. Number of lives.
#'
#' @return Positive integer giving the order statistic rank.
#'
#' @keywords internal
.mc_multilife_status_rank <- function(status, k, n_lives) {
  if (status == "joint") {
    return(1L)
  }

  if (status == "last") {
    return(as.integer(n_lives))
  }

  if (status == "kth_death") {
    if (k > n_lives) {
      stop(
        "`k` must be less than or equal to the number of lives in each simulation.",
        call. = FALSE
      )
    }

    return(as.integer(k))
  }

  if (status == "at_least_k_alive") {
    if (k > n_lives) {
      stop(
        "`k` must be less than or equal to the number of lives in each simulation.",
        call. = FALSE
      )
    }

    return(as.integer(n_lives - k + 1L))
  }

  stop("Unknown multiple-life status.", call. = FALSE)
}
